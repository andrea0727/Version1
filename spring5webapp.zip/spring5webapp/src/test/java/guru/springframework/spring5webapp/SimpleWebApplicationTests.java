package guru.springframework.spring5webapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
